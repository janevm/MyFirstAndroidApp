package com.example.moneytracking.di

interface Injectable