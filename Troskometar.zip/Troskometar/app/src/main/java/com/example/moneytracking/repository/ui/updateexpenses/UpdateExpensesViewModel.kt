package com.example.moneytracking.repository.ui.updateexpenses

import androidx.lifecycle.ViewModel

import com.example.moneytracking.database.MoneyTrackDatabaseDao
import com.example.moneytracking.model.MoneyTrack
import com.example.moneytracking.repository.MoneyRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject

class UpdateExpensesViewModel @Inject constructor(dataSource: MoneyTrackDatabaseDao) : ViewModel() {
	private val repository: MoneyRepository = MoneyRepository(dataSource)
	fun updateExpenses(
		expenseId: Long,
		categoryExpense: String,
		sumExpense: Long,
		dateExpense: Long,
	) {
		CoroutineScope(Dispatchers.IO).launch {
			val newExpense = MoneyTrack(expenseId = expenseId,
				categoryExpense = categoryExpense,
				sumExpense = sumExpense,
				dateExpense = dateExpense)
			repository.update(newExpense)
		}
	}
}